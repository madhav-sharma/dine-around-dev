//
//  PurchaseHistoryVC.swift
//  DineAround
//
//  Created by Gold_Mac on 5/11/17.
//  Copyright © 2017 gold. All rights reserved.
//

import UIKit

class PurchaseHistoryVC: UITableViewController {

    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var purchaseDateLabel: UILabel!
    @IBOutlet weak var endSubLabel: UILabel!
    @IBOutlet weak var moneyLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */


}

