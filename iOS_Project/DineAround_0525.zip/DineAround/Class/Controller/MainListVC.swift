//
//  MainListVC.swift
//  DineAround
//
//  Created by Gold_Mac on 5/6/17.
//  Copyright © 2017 gold. All rights reserved.
//

import UIKit

extension UIViewController {
    var app:AppDelegate {
        return UIApplication.shared.delegate as! AppDelegate
    }
    
    var localData: UserDefaults {
        return UserDefaults.standard
    }
    
    func showAlert(title: String!, message: String!, withField field:UITextField! = nil) {
        let alertVC = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
            if let field = field {
                field.updateFocusIfNeeded()
            }
        }))
        self.present(alertVC, animated: true, completion: nil)
    }
}

class MainListVC: UIViewController {
    
    @IBOutlet weak var categoryView: UIView!
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var cuisineScrollView: UIScrollView!
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var filterView: UIView!
    
    @IBOutlet weak var visitedImgView: UIImageView!
    @IBOutlet weak var neverBeenImgView: UIImageView!
    
    var selectedType = 1
    
    var locations: [Location] = []
    
    var isLoadDB = false
    
    
    //
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.loadFromServer()
        
        self.createCuisineButton()
        
        self.initFilterScreen()
        
        searchBar.isHidden = true
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationItem.title = "ANN ARBOR"
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "showDetail" {
            navigationItem.title = ""
            if let loc = sender as? Location, let detailVC = segue.destination as? DetailVC {
                
                detailVC.restaurant = loc
            }
        }
    }
    
    func loadFromServer() {
        if self.isLoadDB == true {
            return
        }
        self.isLoadDB = true
        SwiftLoader.show(title: "Fetching data from server...", animated: true)
        
        ApiManager.shared.getLocations { (locArray) in
            
            if let locArray = locArray {
                self.locations = locArray
            }
            else {
                self.isLoadDB = false
            }

            self.testLocation()
            
            self.tableView.reloadData()
            SwiftLoader.hide()
        }
    }
    
    func testLocation() {
        
        let dictArray: [[String:Any?]] = [
            ["key":"locations1", "id": "1", "name": "Spencer", "latitude":"42.279728", "longitude":"-83.747866", "address": "113 E Liberty St", "city":"Ann Arbor", "state":"MI", "postal":"48104", "cuisines": "American, Cheese", "phone":"(734) 369-3979", "url":"spencerannarbor.com",  "logo": "loc_logo", "pictures":["loc_img1", "loc_img2", "loc_img3"], "menu_image": "location_menu", "hours": "Mon\t11:00 am - 3:00 pm\n5:00 pm - 10:00 pm\nTue\tClosed\nWed\t11:00 am - 3:00 pm\n5:00 pm - 10:00 pm\nThu\t:00 am - 3:00 pm\n5:00 pm - 10:00 pm\nFri\t11:00 am - 3:00 pm\n5:00 pm - 11:00 pm\nSat\t:00 am - 3:00 pm\n5:00 pm - 11:00 pm\nSun\t11:00 am - 3:00 pm\n5:00 pm - 10:00 pm\n", "entree_cost": "30", "feature":"creditcard,wheelchair"],
            
            ["key":"locations2", "id": "2", "name": "Tmaz Taqueria", "latitude":"42.279728", "longitude":"-83.747866", "address": "3182 Packard St", "city":"Ann Arbor", "state":"MI",  "postal": "48108", "cuisines": "Mexcian", "phone":"(734) 477-6089", "url":"taqueriatmaz.com",  "logo": "res1", "pictures":["res_info1", "res_info3", "res_info4"], "menu_image": "res_info2", "hours": "Mon\t11:00 am - 11:00 pm\nTue\t11:00 am - 11:00 pm\nWed\t11:00 am - 11:00 pm\nThu\t11:00 am - 11:00 pm\nFri\t4:00 pm - 11:00 pm\nSat\t11:00 am - 11:00 pm\nSun\tClosed", "entree_cost": "20"],
            
            ["key":"locations3", "id": "3", "name": "Once-Upon A Grill", "latitude":"42.279728", "longitude":"-83.747866", "address": "3148 Packard Rd", "city":"Ann Arbor", "state":"MI",  "postal": "48108", "cuisines": "Indian", "phone":"(734) 997-5277", "url":"",  "logo": "Once1", "pictures":["res_info1", "res_info3", "res_info4"], "menu_image": "menu2", "hours": "Mon\t11:00 am - 11:00 pm\nTue\t11:00 am - 11:00 pm\nWed\t11:00 am - 11:00 pm\nThu\t11:00 am - 11:00 pm\nFri\t4:00 pm - 11:00 pm\nSat\t11:00 am - 11:00 pm\nSun\t11:00 am - 11:00 pm", "entree_cost": "10"],
            
            ["key":"locations4", "id": "4", "name": "Mani Osteria & Bar", "latitude":"42.279728", "longitude":"-83.747866", "address": "341 E Liberty St", "city":"Ann Arbor", "state":"MI",  "postal": "48104", "cuisines": "Italian", "phone":"(734) 769-6700", "url":"maniosteria.com",  "logo": "mani_logo", "pictures":["res_info1", "res_info3", "res_info4"], "menu_image": "menu1", "hours": "Mon\tClosed\nTue\t11:30 am - 10:00 pm\nWed\t11:30 am - 10:00 pm\nThu\t11:30 am - 10:00 pm\nFri\t11:30 am - 11:00 pm\nSat\t12:00 pm - 11:00 pm\nSun\t11:00 am - 2:30 pm\n\t\t4:00 pm - 9:00 pm", "entree_cost": "20"]
            ]
        
        for dict in dictArray {
            let location = Location(dictionary: dict as NSDictionary)
            locations.append(location)
        }
        
    }
    
    
    
    func createCuisineButton() {
        let cuisineTextArray = ["all", "american", "mexican", "italian", "indian"]
        
        var x: CGFloat = 0
        var rect = CGRect(x: 0, y: 0, width: 120, height: 40)
        var tag = 1
        for titleStr in cuisineTextArray {
            
            rect.origin.x = x
            
            let button = UIButton(type: .custom)
            
            button.setTitle(titleStr.uppercased(), for: .normal)
            button.titleLabel?.font = UIFont(name: "Comfortaa-Bold", size: 16)
            
            button.setTitleColor(UIColor.black, for: .normal)
            button.setTitleColor(UIColor.orange1, for: .selected)
            
            button.frame = rect
            button.addTarget(self, action: #selector(self.actionCuisine(_:)), for: .touchUpInside)
            
            if tag == self.selectedType {
                button.isSelected = true
            }
            
            button.tag = tag
            
            cuisineScrollView.addSubview(button)
            
            x += 128
            tag += 1
        }
        
        cuisineScrollView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 40, right: x)
        
    }
    
    // MARK: - Action
    
    @IBAction func actionCuisine(_ sender: UIButton) {
        if sender.tag == selectedType {
            return
        }
        if let oldButton = cuisineScrollView.viewWithTag(selectedType) as? UIButton {
            oldButton.isSelected = false
        }
        selectedType = sender.tag
        sender.isSelected = true
    }

    @IBAction func actionPrev(_ sender: UIButton) {
        
    }
    
    @IBAction func actionNext(_ sender: UIButton) {
    }
    
    @IBAction func actionFilter(_ sender: UIBarButtonItem) {
        
        if filterView.isHidden == true {
            
            sender.isEnabled = false
            var rect : CGRect = filterView.frame
            rect.origin.y = g_winSize.height
            filterView.frame = rect
            
            filterView.isHidden = false
            
            let y0 = g_winSize.height * 0.25 - 50
            
            UIView.animate(withDuration: 0.5, delay: 0.05, options: [.curveEaseOut], animations: {
            
                rect.origin.y = y0
                self.filterView.frame = rect
            }, completion: {_ in
               sender.isEnabled = true
            })
        }
    }
    
    @IBAction func actionSearch(_ sender: UIBarButtonItem) {
        searchBar.isHidden = !searchBar.isHidden
    }
    
    // MARK: - Filter Screen
    
    func initFilterScreen() {
        filterView.isHidden = true

        visitedImgView.isHidden = true
        neverBeenImgView.isHidden = true
    }
    
    @IBAction func actionFilterDone(_ sender: UIButton) {
        
        if filterView.isHidden == false {
            sender.isEnabled = false
            var rect : CGRect = filterView.frame
            
            let y0 = g_winSize.height
            
            UIView.animate(withDuration: 0.5, delay: 0.05, options: [.curveEaseOut], animations: {
                
                rect.origin.y = y0
                self.filterView.frame = rect
            }, completion: {_ in
                self.filterView.isHidden = true
                sender.isEnabled = true
            })
        }
        
    }
    
    @IBAction func actionFilterVisited(_ sender: UIButton) {
        visitedImgView.isHidden = false
        neverBeenImgView.isHidden = true
    }
    
    @IBAction func actionFilterNeverBeen(_ sender: UIButton) {
        visitedImgView.isHidden = true
        neverBeenImgView.isHidden = false
    }
    
    @IBAction func actionFilterFeatures(_ sender: CheckButton) {
        sender.isSelected = !sender.isSelected
    }
    
}

extension MainListVC: UITableViewDelegate {
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 122
    }
}

extension MainListVC: UITableViewDataSource {
    @available(iOS 2.0, *)
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return locations.count
    }
    
    @available(iOS 2.0, *)
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: MainViewCell.reuseIdentifier(), for: indexPath) as! MainViewCell
        
        cell.tag = indexPath.row
        cell.location = locations[indexPath.row]
        cell.delegate = self
        
        return cell
    }
    
    
}

extension MainListVC: ViewCellDelegate {
    func openView(_ index: Int) {
        self.performSegue(withIdentifier: "showDetail", sender: locations[index])
    }
}
