//
//  InstructionVC.swift
//  DineAround
//
//  Created by Gold_Mac on 5/10/17.
//  Copyright © 2017 gold. All rights reserved.
//

import UIKit

class InstructionVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewDidLayoutSubviews() {
    }
    
}

