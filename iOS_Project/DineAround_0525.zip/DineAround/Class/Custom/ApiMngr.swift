//
//  ApiMngr.swift
//  DineAround
//
//  Created by Gold_Mac on 5/19/17.
//  Copyright © 2017 gold. All rights reserved.
//

import Foundation
import Firebase
import FirebaseAuth
import FirebaseStorageUI

class UserInfo {
    
    public static var _shared: UserInfo! = nil
    
    public class var shared: UserInfo {
        if _shared == nil {
            _shared = UserInfo()
        }
        return _shared
    }
    
    var key: String = ""
    var name: String = ""
    var phone: String = ""
    var email: String = ""
    var password: String = ""
    var isLogin: Bool = false
    
    init() {
        self.load()
    }
    
    func setInfo(_ userInfo: UserInfo!) {
        key = userInfo.key
        name = userInfo.name
        phone = userInfo.phone
        email = userInfo.email
        password = userInfo.password
        isLogin = userInfo.isLogin
    }
    
    func empty() {
        key = ""
        name = ""
        phone = ""
        email = ""
        password = ""
        isLogin = false
    }
    
    func load() {
        let userDefaults = UserDefaults.standard
        self.key = userDefaults.object(forKey: "key") as? String ?? ""
        self.name = userDefaults.object(forKey: "name") as? String ?? ""
        self.phone = userDefaults.object(forKey: "phone") as? String ?? ""
        self.email = userDefaults.object(forKey: "email") as? String ?? ""
        self.password = userDefaults.object(forKey: "password") as? String ?? ""
        self.isLogin = userDefaults.bool(forKey: "isLogin")
    }
    
    func save() {
        let userDefaults = UserDefaults.standard
        
        userDefaults.set(key, forKey: "key")
        userDefaults.set(name, forKey: "name")
        userDefaults.set(phone, forKey: "phone")
        userDefaults.set(email, forKey: "email")
        userDefaults.set(password, forKey: "password")
        userDefaults.set(isLogin, forKey: "isLogin")
        
        userDefaults.synchronize()
    }
}

class ApiManager {
    
    var verifyID: String!
    var verifyCode: String!
    var locDBRef: DatabaseReference!
    var usrDBRef: DatabaseReference!
    
    static var _shared: ApiManager! = nil
    
    class var shared: ApiManager {
        if _shared == nil {
            _shared = ApiManager()
        }
        return _shared
    }
    
    init() {
        locDBRef = Database.database().reference(withPath: "locations")
        usrDBRef = Database.database().reference(withPath: "users")
        self.load()
    }
    
    func load() {
        let userDefaults = UserDefaults.standard
        self.verifyID = userDefaults.object(forKey: "authID") as? String ?? ""
        self.verifyCode = userDefaults.object(forKey: "authCode") as? String ?? ""
    }
    
    func save() {
        let userDefaults = UserDefaults.standard
        userDefaults.set(verifyID, forKey: "authID")
        userDefaults.set(verifyCode, forKey: "authCode")
        userDefaults.synchronize()
    }
    
    func userSignup(userInfo: UserInfo! = nil, completion: @escaping (String!)->()) {
        
        let info = userInfo ?? UserInfo.shared
        
        self.userSignup(phoneNumber: info.phone, name: info.name, email: info.email, password: info.password, completion: completion)
    }
    
    func userSignup(phoneNumber: String!, name: String!, email: String!, password: String!, completion: @escaping (String!)->()) {
//        if self.verifyID != nil && self.verifyID != "" {
//            completion(self.verifyID)
//            return
//        }
        userSignOut()
        PhoneAuthProvider.provider().verifyPhoneNumber(phoneNumber) { (verificationID, error) in
            if error != nil {
                print("\(String(describing: error))")
                completion(nil)
                return
            }
            
            print("\(String(describing: verificationID))")
            
            self.verifyID = verificationID
            self.save()
            
            completion(verificationID)
            return
        }
    }
    
    func userCredential(code: String!, completion: @escaping (String!)->()) {
        let phoneAuth = PhoneAuthProvider.provider().credential(withVerificationID: verifyID, verificationCode: code)
        
        Auth.auth().signIn(with: phoneAuth) { (user, error) in
            if error != nil {
                print("\(error!.localizedDescription)")
                completion(error!.localizedDescription)
                return
            }
            self.verifyCode = code
            self.save()
            
            self.saveUserInfo(user: user)
            UserInfo.shared.isLogin = true
            UserInfo.shared.save()
            
            completion(nil)
        }
    }
    
    func userLogin(phoneNumber: String!, password: String!, completion: @escaping (Int)->()) {
        self.usrDBRef.observe(.value, with: { (snapshot) in
            for item in snapshot.children {
                if let snap = item as? DataSnapshot {
                    if let dict = snap.value as? NSDictionary {
                        print("\(dict)")
                        let phone = dict.value(forKey: "phone") as? String ?? ""
                        let pass = dict.value(forKey: "password") as? String ?? ""
                    
                        print("\(phone) - \(pass)")
                        
                        if phoneNumber == phone && password == pass {
                            
                            print("equals")
                        
                            let userInfo = UserInfo.shared
                            
                            userInfo.key = snap.key
                            userInfo.phone = phone
                            userInfo.password = pass
                            userInfo.name = dict.value(forKey: "name") as? String ?? ""
                            userInfo.email = dict.value(forKey: "email") as? String ?? ""
                            userInfo.isLogin = true
                            
                            userInfo.save()
                            
                            completion(0)
                            return
                        }
                    }
                }
            }
            completion(-1)
        }) { (error) in
            print(error.localizedDescription)
            completion(-2)
        }
    }
    
    func userSignOut() {
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
        } catch let signOutError as NSError {
            print ("Error signing out: %@", signOutError)
        }
    }
    
    func userChange(oldPassword: String!, toNewPassword newPass: String!, completion: @escaping (Int)->()) {

        let userInfo = UserInfo.shared
        
        if (userInfo.password != oldPassword) {
            completion(-1)
            return
        }
        
        if userInfo.key != "" {
            if let pass = newPass {
                
                self.usrDBRef.child(userInfo.key).child("password").setValue(pass, withCompletionBlock: { (error, ref) in
                    
                    if error != nil {
                        completion(-2)
                        return
                    }
                    userInfo.password = newPass
                    userInfo.save()
                    
                    completion(0)
                })
            }
        }
    }
    
    func getLocations(completion: @escaping ([Location]!)->()) {
        self.locDBRef.observe(.value, with: { (snapshot) in
            
            var locArray = [Location]()
            for item in snapshot.children {
                if let snap = item as? DataSnapshot {
                    let loc = Location(snap: snap)
                    locArray.append(loc)
                }
            }
            completion(locArray)
            
        }) { (error) in
            print(error.localizedDescription)
            completion(nil)
        }

    }
    
    func saveUserInfo(user: User!) {
        
        if let user = user {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy/MM/dd"
            let dateString = dateFormatter.string(from: Date())
            
            let userInfo = UserInfo.shared
            userInfo.key = user.uid
            
            let newUser = [
                "phone": userInfo.phone,
                "name": userInfo.name,
                "email": userInfo.email,
                "provider": user.providerID,
                "password": userInfo.password,
                "createdAt": dateString
            ]
            
            self.usrDBRef.child(user.uid).setValue(newUser)
            
        }
        else {
            print("user is nil")
        }

    }
}
