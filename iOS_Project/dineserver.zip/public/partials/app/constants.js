angular.
        module('Constants', [])
        .constant('APIpath', {
            'API_PATH': 'http://192.168.0.200:7373/',
        });

